document.addEventListener('DOMContentLoaded', loadTasks);

function addTask() {
    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const dueDate = document.getElementById('due-date').value;
    const priority = document.getElementById('priority').value;
    const category = document.getElementById('category').value;

    const task = {
        title,
        description,
        dueDate,
        priority,
        category,
        status: 'New'
    };

    saveTask(task);
    loadTasks();
    clearForm();

    setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 100); // Adjust the delay as needed
}

function saveTask(task) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.push(task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function loadTasks() {
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';

    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];

    tasks.forEach((task, index) => {
        const taskDiv = document.createElement('div');
        taskDiv.classList.add('task');
        if (task.status === 'Completed') {
            taskDiv.classList.add('completed');
        }

        taskDiv.innerHTML = `
            <h3>${task.title}</h3>
            <p>${task.description}</p>
            <p>Due Date: ${task.dueDate}</p>
            <p>Priority: ${task.priority}</p>
            <p>Category: ${task.category}</p>
            <p>Status: ${task.status}</p>
            <button onclick="completeTask(${index})">Complete</button>
        `;

        taskList.appendChild(taskDiv);
    });
}

function completeTask(index) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks[index].status = 'Completed';
    localStorage.setItem('tasks', JSON.stringify(tasks));
    loadTasks();
}

function clearForm() {
    document.getElementById('title').value = '';
    document.getElementById('description').value = '';
    document.getElementById('due-date').value = '';
    document.getElementById('priority').value = 'low';
    document.getElementById('category').value = '';
}


function refreshPage() {
    location.reload();
}

// Add this function in app.js
function clearAllTasks() {
    if (confirm("Are you sure you want to clear all tasks?")) {
        localStorage.removeItem('tasks');
        loadTasks(); // Reload the tasks to update the UI
    }
}
